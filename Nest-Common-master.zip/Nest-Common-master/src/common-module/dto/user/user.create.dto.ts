export abstract class UserCreateDto {
    username: string;
    password: string;
}